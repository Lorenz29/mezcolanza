export const HEADER_ZKEY_SECTION = 1;

export const GROTH16_PROTOCOL_ID = 1;
export const PLONK_PROTOCOL_ID = 2;
export const FFLONK_PROTOCOL_ID = 10;
